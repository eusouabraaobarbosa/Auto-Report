from django.urls import path
from .views import PedidoKey, ActiveKey, activit_redirect, ListaKey

urlpatterns = [
    path('licenca/', activit_redirect, name='licenca'),
    path('pedido/', PedidoKey.as_view(), name='pedido'),
    path('valid-key/', ListaKey.as_view(), name='check-key'),
    path('active/<int:pk>', ActiveKey.as_view(), name='active'),

]