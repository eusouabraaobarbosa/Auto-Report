from django import forms
from config.models import Config

class ConfigForm(forms.ModelForm):
    class Meta:
        model = Config
        fields = ['usuario', 'senha', 'porta', 'p_winbox', 'd_um', 'd_dois', 'hora_execucao', 'minuto_execucao']
        widgets = {
            'usuario': forms.TextInput(attrs={'class': 'form-control'}),
            'senha': forms.PasswordInput(attrs={'class': 'form-control'}),
            'porta': forms.NumberInput(attrs={'class': 'form-control'}),
            'p_winbox': forms.NumberInput(attrs={'class': 'form-control'}),
            'd_um': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 31}),
            'd_dois': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 31}),
            'hora_execucao': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'max': 23}),
            'minuto_execucao': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'max': 59}),
        }