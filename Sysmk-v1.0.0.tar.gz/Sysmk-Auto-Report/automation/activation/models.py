from django.db import models
from django.utils import timezone
from simple_history.models import HistoricalRecords
from django.contrib.auth.models import User


class Licence(models.Model):
    email = models.CharField(max_length=70, unique=True, blank=False, verbose_name='email', default='suporte@introtech.com.br')
    key_licence = models.CharField(max_length=70, unique=True, blank=False, verbose_name='key_licence', default='introtech-licence-key-free-trial')
    plano = models.CharField(max_length=8, unique=True, blank=False, verbose_name='plano', default='Mensal')
    is_active = models.BooleanField(default=False)
    data = models.DateTimeField(default=timezone.now)
    user = models.ForeignKey(User, on_delete=models.PROTECT, verbose_name='user')
    pg_key = models.BooleanField(default=False)

    history = HistoricalRecords()

    class Meta:
        ordering = ['email']

    def __str__(self):
        return self.email
