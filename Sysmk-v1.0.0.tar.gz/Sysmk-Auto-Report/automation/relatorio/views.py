from braces.views import GroupRequiredMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.list import ListView
from relatorio.models import Lista, Falhas
from django.urls import reverse_lazy
from django.db.models import Q

class ListaRB(GroupRequiredMixin, LoginRequiredMixin, ListView):
    login_url = reverse_lazy('denied')
    group_required = [u'suporte', u'admin']
    template_name = 'relatorio/relatorio.html'


    def get_queryset(self):
        search_query = self.request.GET.get('search')
        
        # Filtra a tabela 'Lista'
        rb = Lista.objects.all()
        if search_query:
            rb = rb.filter(Q(name__icontains=search_query))
        
        return rb
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Filtra a tabela 'Falhas'
        search_query = self.request.GET.get('search')
        fb = Falhas.objects.all()
        if search_query:
            fb = fb.filter(Q(description__icontains=search_query))
        
        context['falhas_list'] = fb
        return context

