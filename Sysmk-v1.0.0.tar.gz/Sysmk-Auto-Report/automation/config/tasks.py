from celery import shared_task
import datetime

@shared_task
def executar_programa():
    # Lógica da tarefa
    print(f"Tarefa executada em {datetime.datetime.now()}")
