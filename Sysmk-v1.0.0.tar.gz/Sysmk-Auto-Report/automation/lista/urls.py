from django.urls import path
from .views import ListaDB


urlpatterns = [
    
    path('', ListaDB.as_view(), name='lista'),
    

]