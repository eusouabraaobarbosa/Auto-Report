from django.db import models
from django.utils import timezone
from simple_history.models import HistoricalRecords
from django.contrib.auth.models import User


class Lista(models.Model):
    data = models.CharField(max_length=50, unique=False, blank=True, verbose_name='data')
    ssid = models.CharField(max_length=50, unique=False, blank=True, verbose_name='ssid')
    ip = models.CharField(max_length=50, unique=False, blank=True, verbose_name='ip')
    frequency = models.CharField(max_length=50, unique=False, blank=True, verbose_name='frequency')
    mode = models.CharField(max_length=50, unique=False, blank=True, verbose_name='mode')
    band = models.CharField(max_length=50, unique=False, blank=True, verbose_name='band')
    channel = models.CharField(max_length=50, unique=False, blank=True, verbose_name='channel')
    protocol = models.CharField(max_length=50, unique=False, blank=True, verbose_name='protocol')
    name = models.CharField(max_length=50, unique=False, blank=True, verbose_name='name')
    mac = models.CharField(max_length=50, unique=False, blank=True, verbose_name='mac')
    sinaltx = models.CharField(max_length=50, unique=False, blank=True, verbose_name='sinaltx')
    sinalrx = models.IntegerField(unique=False, blank=True, verbose_name='sinalrx')
    version = models.CharField(max_length=50, unique=False, blank=True, verbose_name='version')

    class Meta:
        ordering = ['ssid', 'sinalrx']
    
    def __str__(self):
        return self.ssid
