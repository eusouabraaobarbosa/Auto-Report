from django.db import models
from django.utils import timezone
from simple_history.models import HistoricalRecords
from django.contrib.auth.models import User




class Config(models.Model):

    usuario = models.CharField(max_length=15, unique=True, blank=False, verbose_name='usuario', default='admin')
    senha = models.CharField(max_length=15, unique=True, blank=False, verbose_name='senha', default='password123')
    porta = models.CharField(max_length=8, unique=True, blank=False, verbose_name='porta', default='22')
    p_winbox = models.CharField(max_length=8, unique=True, blank=False, verbose_name='p_winbox', default='8291')
    d_um = models.CharField(max_length=2, default="10")
    d_dois = models.CharField(max_length=2, default="20")
    hora_execucao = models.CharField(max_length=2, default="00")
    minuto_execucao = models.CharField(max_length=2, default="00")



    user = models.ForeignKey(User, on_delete=models.PROTECT, null=True)
    data = models.DateTimeField(default=timezone.now)
    history = HistoricalRecords()

    def save(self, *args, **kwargs):
        # Formata os valores para sempre ter dois dígitos
        self.d_um = f"{int(self.d_um):02}"
        self.d_dois = f"{int(self.d_dois):02}"
        self.hora_execucao = f"{int(self.hora_execucao):02}"
        self.minuto_execucao = f"{int(self.minuto_execucao):02}"
        super(Config, self).save(*args, **kwargs)

    class Meta:
        ordering = ['user']

    def __str__(self):
        return self.user
