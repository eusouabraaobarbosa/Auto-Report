from braces.views import GroupRequiredMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.list import ListView
from lista.models import Lista
from django.urls import reverse_lazy
from django.db.models import Q

#def lista(request):
    #return render(request, 'lista/lista.html')

class ListaDB(GroupRequiredMixin, LoginRequiredMixin, ListView):
    login_url = reverse_lazy('denied')
    group_required = [u'suporte', u'admin']
    model = Lista
    template_name = 'lista/lista.html'
    paginate_by = 30

    def get_queryset(self):
        search_query = self.request.GET.get('search', '').strip()
        filter_type = self.request.GET.get('filter_type', '')
    
        # Começa com todos os objetos
        db = Lista.objects.all()
    
        if search_query:
            if filter_type == 'data':
                db = db.filter(data__icontains=search_query)
            elif filter_type == 'ssid':
                db = db.filter(ssid__icontains=search_query)
            elif filter_type == 'ip':
                db = db.filter(ip__icontains=search_query)
            elif filter_type == 'name':
                db = db.filter(name__icontains=search_query)
            elif filter_type == 'sinalrx':
                try:
                    # Converte o valor de search_query em um número inteiro
                    sinalrx_value = int(search_query)
                    # Filtra os objetos que têm sinalrx maior que o valor especificado
                    db = db.filter(sinalrx__lte=sinalrx_value)
                except ValueError:
                    # Caso o valor de search_query não seja um número inteiro válido
                    pass

        return db
