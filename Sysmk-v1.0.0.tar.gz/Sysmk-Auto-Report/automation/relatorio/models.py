from django.db import models
from django.utils import timezone
from simple_history.models import HistoricalRecords
from django.contrib.auth.models import User


class Lista(models.Model):
    name = models.CharField(max_length=50, unique=False, blank=True, verbose_name='name')
    data = models.CharField(max_length=50, unique=False, blank=True, verbose_name='data')
    total = models.CharField(max_length=50, unique=False, blank=True, verbose_name='total')
    success = models.CharField(max_length=50, unique=False, blank=True, verbose_name='success')
    fails = models.CharField(max_length=50, unique=False, blank=True, verbose_name='fails')

    class Meta:
        ordering = ['-name']
    
    def __str__(self):
        return self.name
    
class Falhas(models.Model):
    data = models.CharField(max_length=50, unique=False, blank=True, verbose_name='data')
    ip = models.CharField(max_length=50, unique=False, blank=True, verbose_name='ip')
    fails = models.CharField(max_length=100, unique=False, blank=True, verbose_name='fails')

    class Meta:
        ordering = ['-data']
    
    def __str__(self):
        return self.data


