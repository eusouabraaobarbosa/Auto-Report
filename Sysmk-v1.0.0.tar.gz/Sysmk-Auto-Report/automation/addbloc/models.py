from django.db import models
from django.utils import timezone
from simple_history.models import HistoricalRecords
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
import ipaddress


def validate_ipv4_block(value):
    try:
        network = ipaddress.IPv4Network(value, strict=False)
    except ValueError:
        raise ValidationError(f'{value} não é um bloco de IPv4 válido.')


class Addbloc(models.Model):
    ip_bloc = models.CharField(max_length=18, unique=True, blank=False, verbose_name='ip_bloc', validators=[validate_ipv4_block])
    is_active = models.BooleanField(default=True)
    data = models.DateTimeField(default=timezone.now)
    user = models.ForeignKey(User, on_delete=models.PROTECT, verbose_name='user')
    history = HistoricalRecords()

    class Meta:
        ordering = ['-is_active']

    def __str__(self):
        return self.ip_bloc
