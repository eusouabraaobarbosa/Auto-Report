from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse
from django.shortcuts import render
from addbloc.models import Addbloc
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse_lazy
from braces.views import GroupRequiredMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.views.generic import DeleteView
from django.utils import timezone
from django.db.models import Q


class CadastroAB(GroupRequiredMixin, SuccessMessageMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('denied')
    group_required = [u'admin']
    model = Addbloc
    fields = ['ip_bloc']
    #form_class = AddblocForm
    template_name = 'addbloc/cadastro.html'
    success_url = reverse_lazy('lista-ip')
    success_message = 'IP adicionando com sucesso!'
    
    def get_form(self, form_class=None):
        form = super(CadastroAB, self).get_form(form_class)
        form.fields['ip_bloc'].label = "Informe o IP"  # Alterar a label diretamente aqui
        return form
    
    def form_valid(self, form):
        form.instance.user = self.request.user
        form.instance.data = timezone.now()
        return super(CadastroAB, self).form_valid(form)


class ListaAB(GroupRequiredMixin, LoginRequiredMixin, ListView):
    login_url = reverse_lazy('denied')
    group_required = [u'suporte', u'admin']
    model = Addbloc
    template_name = 'addbloc/lista-ip.html'

    def get_queryset(self):
        search_query = self.request.GET.get('search')
    
        # Começa com todos os objetos
        ab = Addbloc.objects.all()
    
        if search_query:
            # Aplica o filtro em SSID, IP ou data
            ab = ab.filter(
                Q(ip_bloc__icontains=search_query)      
            )
        
        return ab


class DeleteAB(GroupRequiredMixin, SuccessMessageMixin, LoginRequiredMixin, DeleteView):
    login_url = reverse_lazy('denied')
    group_required = [u'admin']
    model = Addbloc
    template_name = 'addbloc/excluir.html'
    success_url = reverse_lazy('lista-ip')
    success_message = 'Excluido com sucesso!'


def toggle_block(request, pk):
    block = get_object_or_404(Addbloc, pk=pk)
    if request.method == "POST":
        is_active = request.POST.get('is_active') == 'on'
        block.is_active = is_active
        block.save()
    return redirect(reverse('lista-ip'))