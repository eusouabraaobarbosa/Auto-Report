from config.forms import ConfigForm
from config.models import Config
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse_lazy
from braces.views import GroupRequiredMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic.edit import CreateView, UpdateView
from django.utils import timezone
from django.contrib.auth.hashers import make_password
from django.shortcuts import redirect

class CreateConfig(GroupRequiredMixin, SuccessMessageMixin, LoginRequiredMixin, CreateView):
    login_url = reverse_lazy('denied')
    group_required = [u'admin']
    model = Config
    form_class = ConfigForm  # Use o formulário configurado
    template_name = 'config/config.html'
    success_url = reverse_lazy('config_up', kwargs={'pk': 1})
    success_message = 'Salvo com sucesso!'
    
    def form_valid(self, form):
        form.instance.id = 1
        form.instance.user = self.request.user
        form.instance.data = timezone.now()
        return super(CreateConfig, self).form_valid(form)
    
class EditConfig(GroupRequiredMixin, SuccessMessageMixin, LoginRequiredMixin, UpdateView):
    login_url = reverse_lazy('denied')
    group_required = [u'admin']
    model = Config
    form_class = ConfigForm  # Use o formulário configurado
    template_name = 'config/config.html'
    success_url = reverse_lazy('config_up', kwargs={'pk': 1})
    success_message = 'Atualizado com sucesso!'
    
    def get_object(self):
        return Config.objects.get(pk=1)

def settings_redirect(request):
    try:
        settings = Config.objects.get(user=request.user)
        return redirect('config_up', pk=settings.pk)
    except Config.DoesNotExist:
        return redirect('config')
