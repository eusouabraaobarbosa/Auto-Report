from django.urls import path
from .views import CadastroAB, ListaAB, DeleteAB, toggle_block

urlpatterns = [
    path('toggle-block/<int:pk>/', toggle_block, name='toggle-block'),
    path('cadastro-ip/', CadastroAB.as_view(), name='cadastro_ip'),
    path('lita-ip/', ListaAB.as_view(), name='lista-ip'),
    path('delete/<int:pk>', DeleteAB.as_view(), name='delete-ip'),
]

