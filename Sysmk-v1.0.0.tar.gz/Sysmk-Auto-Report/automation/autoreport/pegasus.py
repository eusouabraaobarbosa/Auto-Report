import os
import schedule
import time
import MySQLdb
import threading
from datetime import datetime
import subprocess



hora_agendada = "16:00"
# Seu script aqui
def run_on_startup():
    global hora_agendada

    def db_conect():
        conn = MySQLdb.connect(
            host="localhost",
            user="db_auto",
            passwd="dbreport24",
            db="db_report"
        )
        return conn

    def data_collect():
        try:
            db = db_conect()
            cursor = db.cursor()
            sql = "SELECT d_um, d_dois, hora_execucao, minuto_execucao FROM config_config"

            try:
                cursor.execute(sql)
                result = cursor.fetchall()
                for v in result:
                    return v
            except MySQLdb.Error as err:
                return []
            finally:
                cursor.close()
                db.close()
        except Exception as err:
            return []

    def job():
        path = f'{os.path.dirname(os.path.dirname(os.path.abspath(__file__)))}/config/command/run.py'
        comando = [f'{os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))}/venv/bin/python3', path]
        subprocess.Popen(comando)

    def check_dates():
        data = data_collect()
        if data:
            dia1 = data[0]
            dia2 = data[1]
            today = str(datetime.now().day)
            if len(today) == 1:
               today = f'0{today}'
            if today == dia1 or today == dia2:
                job()

    def check_time_update(nova_hora):
        global hora_agendada
        hora_agendada = nova_hora
        schedule.clear()  # Remove o agendamento anterior
        schedule.every().day.at(hora_agendada).do(check_dates)  # Reagenda com a nova hora


    # Pega a hora inicial do banco de dados
    try:
        data = data_collect()
        hora_agendada = f"{data[2]}:{data[3]}" if data else "16:00"
    except:
        hora_agendada = "16:00"

    # Agendar a verificação inicial para ser executada todos os dias
    schedule.every().day.at(hora_agendada).do(check_dates)

    # Loop de execução do scheduler
    while True:
        time.sleep(5)
        data = data_collect()
        if data:
            nova_hora = f"{data[2]}:{data[3]}"
            if nova_hora != hora_agendada:
                check_time_update(nova_hora)
        try:
            schedule.run_pending()
            time.sleep(1)
        except Exception as e:
            pass

    
run_on_startup()
