from django.urls import path
from .views import CreateConfig, EditConfig, settings_redirect

urlpatterns = [
    path('settings/', settings_redirect, name='settings'),
    path('config/', CreateConfig.as_view(), name='config'),
    path('update/<int:pk>', EditConfig.as_view(), name='config_up'),
]